# business_rules_js
Required js files for Drupal module Business

https://www.drupal.org/project/business_rules

Copy this files and paste into \libraries\business_rules_js folder.

This files are the adaption of mxGraph to work with the Drupal module Business
Rules.

## mxGraph project:
https://github.com/jgraph/mxgraph